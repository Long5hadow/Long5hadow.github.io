﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_compass_direction_pointer_img = ''
        let normal_battery_circle_scale = ''
        let normal_distance_current_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_day_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_second_text_font = ''
        let normal_time_gmt_text = ''
        let worldClockIndex = 0
        let normal_second_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let GMT_Button_NextSity = ''
        let timeSensor = '';
        let worldClock = '';
        worldClockIndex = hmFS.SysProGetInt('worldClockIndex') ?? 0;;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Los Andes  Lota Grotesque Semi Bold Italic.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 325,
              h: 39,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFFEFDA0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ClassicCobra.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 627,
              h: 26,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ClassicCobra.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Los Andes  Lota Grotesque Semi Bold Italic.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 313,
              h: 37,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFE6E6E6,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Los Andes  Lota Grotesque Semi Bold Italic.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 516,
              h: 62,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFE6E6E6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Michroma.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFE6E6E6,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Michroma.ttf; FontSize: 80
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1462,
              h: 136,
              text_size: 80,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFE6E6E6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: lcd_ds_1_bolditalic.ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 564,
              h: 54,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcd_ds_1_bolditalic.ttf',
              color: 0xFFE6E6E6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: lcd_ds_1_bolditalic.ttf; FontSize: 45; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 54,
              h: 54,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcd_ds_1_bolditalic.ttf',
              color: 0xFFE6E6E6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 312,
              h: 52,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Back-21.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 9,
              src: 'bluetooth-off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 9,
              src: 'alarm-3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 354,
              w: 40,
              h: 180,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFFEFDA0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'km',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 168,
              y: 354,
              w: 70,
              h: 180,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFFEFDA0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'steps',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 270,
              y: 354,
              w: 70,
              h: 180,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFFEFDA0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'bpm',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 392,
              w: 110,
              h: 180,
              text_size: 27,
              char_space: 0,
              font: 'fonts/ClassicCobra.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'gmt',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 337,
              w: 70,
              h: 25,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 270,
              y: 337,
              w: 40,
              h: 25,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Compass-17.png',
              // center_x: 195,
              // center_y: 125,
              // x: 67,
              // y: 67,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 67,
              pos_y: 125 - 67,
              center_x: 195,
              center_y: 125,
              src: 'Compass-17.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 70,
              // center_y: 125,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 38,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFEFDA0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 70,
              center_y: 125,
              start_angle: 0,
              end_angle: 360,
              radius: 37,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFEFDA0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 70,
              y: 337,
              w: 60,
              h: 25,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 155,
              y: 106,
              w: 80,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/Los Andes  Lota Grotesque Semi Bold Italic.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 275,
              w: 90,
              h: 40,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 230,
              y: 275,
              w: 90,
              h: 40,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 170,
              y: 275,
              w: 50,
              h: 40,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 190,
              w: 390,
              h: 90,
              text_size: 80,
              char_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 290,
              y: 105,
              w: 60,
              h: 40,
              text_size: 45,
              char_space: 0,
              font: 'fonts/lcd_ds_1_bolditalic.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_time_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 410,
              w: 150,
              h: 35,
              text_size: 45,
              char_space: 0,
              font: 'fonts/lcd_ds_1_bolditalic.ttf',
              color: 0xFFE6E6E6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeGMT
            function updateTimeGMT() {
              console.log('updateTimeGMT()');
              let normal_timeStr = '--:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let hour = worldData.hour;
                let minute = worldData.minute;
                if (!timeSensor.is24Hour) hour = hour % 12 || 12;
                let normal_hourStr = hour.toString().padStart(2, '0');
                let normal_minuteStr = minute.toString().padStart(2, '0');
                normal_timeStr = normal_hourStr + ':' + normal_minuteStr;
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_timeStr = 'pm ' + normal_timeStr;
                  else normal_timeStr = 'am ' + normal_timeStr;
                };
              } // count
              if (normal_time_gmt_text) normal_time_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeStr);
            };
            //#endregion
            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 320,
              // center_y: 125,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 38,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFEFDA0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 320,
              center_y: 125,
              start_angle: 0,
              end_angle: 360,
              radius: 37,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFEFDA0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 149,
              // start_y: 159,
              // color: 0xFF808080,
              // lenght: 34,
              // line_width: 24,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 151,
              src: 'empty-battery_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 200,
              y: 149,
              w: 60,
              h: 40,
              text_size: 26,
              char_space: 0,
              font: 'fonts/Oswald.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 9,
              src: 'bluetooth-off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 9,
              src: 'alarm-3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 190,
              w: 390,
              h: 90,
              text_size: 80,
              char_space: 0,
              font: 'fonts/Michroma.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 80,
              w: 90,
              h: 90,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 196,
              w: 90,
              h: 90,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            GMT_Button_NextSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 410,
              w: 36,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 18,
              press_color: 0xFFFFFFAA,
              normal_color: 0xFF000000,
              // vibro: True,
              click_func: (button_widget) => {
                toggleWorldClock(1);
                vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region toggleWorldClock
            function toggleWorldClock(step = 1) {
              const count = worldClock.getWorldClockCount();
              if (count) {
                worldClockIndex += step;
                worldClockIndex = worldClockIndex < 0 ? count + worldClockIndex : worldClockIndex % count;
                updateWorldTime(true);
                hmFS.SysProSetInt('worldClockIndex', worldClockIndex);
              }
            };
            //#endregion

            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            //#region updateWorldTime
            function updateWorldTime(updateSity = false) {
              updateTimeGMT();
            };
            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              // Second Circle
              let normal_secondCircleProgress = 100 * second/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //#endregion
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 70,
                      center_y: 125,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 37,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFFFEFDA0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 149;
                  let start_y_idle_battery = 159;
                  let lenght_ls_idle_battery = 34;
                  let line_width_ls_idle_battery = 24;
                  let color_ls_idle_battery = 0xFF808080;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                updateWorldTime();
                setTimeout(() => {
                  if (worldClock) {
                    worldClock.uninit();
                    worldClock.init();
                  };
                }, 500);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                worldClock.uninit();
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}